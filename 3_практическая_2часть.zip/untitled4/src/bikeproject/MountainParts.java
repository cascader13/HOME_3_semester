package bikeproject;

public interface MountainParts {
    final String TERRAIN = "off_road";

    String getSuspension();
    String getType();
    void setSuspension(String newValue);
    void setType(String newValue);

}
