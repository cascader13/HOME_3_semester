package bikeproject;

public interface RoadParts {
    final String terrain = "track_racing";

    Integer getTyreWidth();
    Integer getPostHeight();
    void setTyreWidth(Integer newValue);
    void setPostHeight(Integer newValue);
}
