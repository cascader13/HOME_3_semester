package bikeproject;

public interface BikeParts {
    final String make = "Oracle Cycles";
    public String getHandleBars();
    public void setHandleBars(String newValue);
    public String getFrame();
    public void setFrame(String newValue);
    public String getTyres();
    public void setTyres(String newValue);
    public String getSeatType();
    public void setSeatType(String newValue);
    public int getNumGears();
    public void setNumGears(int newValue);
}
